create definer = root@`%` view total_author_book_value as
select concat(`a`.`first_name`, ' ', `a`.`last_name`)   AS `name`,
       timestampdiff(YEAR, `a`.`birth_date`, curdate()) AS `age`,
       count(distinct `b`.`isbn`)                       AS `book_title_count`,
       concat(sum((`b`.`price` * `i`.`amount`)), ' kr') AS `inventory_value`
from ((`bookstore`.`author` `a` join `bookstore`.`book` `b`
       on ((`a`.`id` = `b`.`author_id`))) join `bookstore`.`inventory` `i` on ((`b`.`isbn` = `i`.`isbn`)))
group by `a`.`id`;

